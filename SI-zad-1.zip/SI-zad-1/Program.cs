﻿// See https://aka.ms/new-console-template for more information
using SI_zad_1;
using SI_zad_1.Models;

List<StationCost>? stationsCost = Loader.LoadData<StationCost>("Data/easy_cost.json");
List<StationFlow>? stationsFlow = Loader.LoadData<StationFlow>("Data/easy_flow.json");
Console.WriteLine(stationsCost);
Console.WriteLine(stationsFlow);

Specimen randomSpecimen = new Specimen(3, 4);
randomSpecimen.GenerateRandomSpecimen(12);
_ = randomSpecimen.SpecimenCost(stationsCost, stationsFlow);
