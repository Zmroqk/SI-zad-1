﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SI_zad_1.Models
{
    internal class StationFlow
    {
        public int Source { get; set; }
        public int Dest { get; set; }
        public int Flow { get; set; }
    }
}
