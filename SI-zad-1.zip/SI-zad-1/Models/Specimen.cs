﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SI_zad_1.Models
{
    internal class Specimen
    {
        int W { get; set; }
        int H { get; set; }
        List<(int, int)> Stations;

        public Specimen(int w, int h)
        {
            W = w;
            H = h;
            Stations = new List<(int, int)>();
        }

        public void GenerateRandomSpecimen(int n)
        {
            int length = W*H;
            if (n > length)
            {
                throw new ArgumentException("N value cannot be bigger than matrix length");
            }
            List<int> positionsTaken = new List<int>();
            int i = 0;
            Random random = new Random();
            while(i < n)
            {
                int position = random.Next(0, n);
                if (!positionsTaken.Contains(position)) {
                    positionsTaken.Add(position);
                    i++;
                }
            }
            for(int j = 1; j <= positionsTaken.Count; j++)
            {
                Stations.Add((positionsTaken[j - 1] / H, positionsTaken[j - 1] % H));
            }
        }

        public int SpecimenCost(List<StationCost> stationCosts, List<StationFlow> stationFlows)
        {
            int fitness = 0;
            int stationIndex = 1;
            foreach((int x, int y) station in Stations)
            {
                List<StationCost> costs = stationCosts.FindAll((sCost) => sCost.Source == stationIndex);
                List<StationFlow> flows = stationFlows.FindAll((sFlow) => sFlow.Source == stationIndex);
                foreach(var cost in costs)
                {
                    StationFlow? flow = flows.Find(flow => flow.Dest == cost.Dest);
                    (int x, int y) destCoords = Stations[cost.Dest - 1];
                    if (flow != null)   
                        fitness += cost.Cost * flow.Flow * (Math.Abs(station.x - destCoords.x) + Math.Abs(station.y - destCoords.y));
                    else
                        throw new Exception("Provided data are incorrect");
                }
                stationIndex++;
            }
            return fitness;
        }
    }
}
